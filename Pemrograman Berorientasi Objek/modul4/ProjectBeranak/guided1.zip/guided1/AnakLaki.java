package guided1;

public class AnakLaki extends OrangTua {
    String nama = "King";
}