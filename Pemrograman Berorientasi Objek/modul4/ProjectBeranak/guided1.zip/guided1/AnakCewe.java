package guided1;

public class AnakCewe extends OrangTua {
    String nama = "Queen";
}