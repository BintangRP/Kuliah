package guided1;

public class OrangTua {
    // ...
    public String marga = "Bebas";

    public void sifatBapak() {
        System.out.println("Pemberani");
    }

    public void sifatIbu() {
        System.out.println("Penyayang");
    }
}